#ifndef __$safeprojectname$_H_
#define __$safeprojectname$_H_

#include "Application.h"
#include <glm/glm.hpp>

// Derived application class that wraps up all globals neatly
class $safeprojectname$ : public Application
{
public:

	$safeprojectname$();
	virtual ~$safeprojectname$();

protected:

	virtual bool onCreate(int a_argc, char* a_argv[]);
	virtual void onUpdate(float a_deltaTime);
	virtual void onDraw();
	virtual void onDestroy();

	glm::mat4	m_cameraMatrix;
	glm::mat4	m_projectionMatrix;
	
	//!--TUTORIAL

	//!--TUTORIAL
};

#endif // __$safeprojectname$_H_